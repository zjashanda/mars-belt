const puppeteer = require('puppeteer'); // v23.0.0 or later

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    const timeout = 5000;
    page.setDefaultTimeout(timeout);

    {
        const targetPage = page;
        await targetPage.setViewport({
            width: 1006,
            height: 863
        })
    }
    {
        const targetPage = page;
        await targetPage.goto('chrome://new-tab-page/');
    }
    {
        const targetPage = page;
        await targetPage.goto('https://integration-platform.listenai.com/ai-voice-firmwares/biz/index');
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(LSCloud 聆思开发者中心)'),
            targetPage.locator('div.login_main a'),
            targetPage.locator('::-p-xpath(//*[@id=\\"rc-tabs-0-panel-userSms\\"]/div/div/div/a)'),
            targetPage.locator(':scope >>> div.login_main a'),
            targetPage.locator('::-p-text(LSCloud 聆思开发者中心)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 94.65625,
                y: 16.296875,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(聆思员工登录)'),
            targetPage.locator('div.right-bottom > a.right-bottom-btn'),
            targetPage.locator('::-p-xpath(//*[@id=\\"__layout\\"]/div/div[2]/section/div[1]/div/div/div[3]/a[2])'),
            targetPage.locator(':scope >>> div.right-bottom > a.right-bottom-btn'),
            targetPage.locator('::-p-text(聆思员工登录)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 72,
                y: 32,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        await puppeteer.Locator.race([
            targetPage.locator('section > section img'),
            targetPage.locator('::-p-xpath(//*[@id=\\"snowyHeader\\"]/div[3]/div/div[3]/span/img)'),
            targetPage.locator(':scope >>> section > section img')
        ])
            .setTimeout(timeout)
            .click({
              offset: {
                x: 10,
                y: 10.5,
              },
            });
    }
    {
        const targetPage = page;
        await puppeteer.Locator.race([
            targetPage.locator('li.ant-dropdown-menu-item-active span:nth-of-type(2)'),
            targetPage.locator('::-p-xpath(/html/body/div[5]/div/div/ul/li[4]/span/span[2])'),
            targetPage.locator(':scope >>> li.ant-dropdown-menu-item-active span:nth-of-type(2)'),
            targetPage.locator('::-p-text(退出登录)')
        ])
            .setTimeout(timeout)
            .click({
              offset: {
                x: 43,
                y: 2,
              },
            });
    }
    {
        const targetPage = page;
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(确 定) >>>> ::-p-aria([role=\\"generic\\"])'),
            targetPage.locator('button.ant-btn-primary > span'),
            targetPage.locator('::-p-xpath(/html/body/div[7]/div/div[2]/div/div[1]/div/div/div/div[2]/button[2]/span)'),
            targetPage.locator(':scope >>> button.ant-btn-primary > span'),
            targetPage.locator('::-p-text(确 定)')
        ])
            .setTimeout(timeout)
            .click({
              offset: {
                x: 10.84375,
                y: 8,
              },
            });
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(LSCloud 聆思开发者中心)'),
            targetPage.locator('div.login_main a'),
            targetPage.locator('::-p-xpath(//*[@id=\\"rc-tabs-0-panel-userSms\\"]/div/div/div/a)'),
            targetPage.locator(':scope >>> div.login_main a'),
            targetPage.locator('::-p-text(LSCloud 聆思开发者中心)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 66.65625,
                y: 3.296875,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(聆思员工登录)'),
            targetPage.locator('div.right-bottom > a.right-bottom-btn'),
            targetPage.locator('::-p-xpath(//*[@id=\\"__layout\\"]/div/div[2]/section/div[1]/div/div/div[3]/a[2])'),
            targetPage.locator(':scope >>> div.right-bottom > a.right-bottom-btn'),
            targetPage.locator('::-p-text(聆思员工登录)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 56,
                y: 26,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        await puppeteer.Locator.race([
            targetPage.locator('li.ant-menu-submenu-active > div > span.ant-menu-title-content'),
            targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/section/aside/div/div/div/ul/li[2]/div/span[2])'),
            targetPage.locator(':scope >>> li.ant-menu-submenu-active > div > span.ant-menu-title-content'),
            targetPage.locator('::-p-text(产品管理)')
        ])
            .setTimeout(timeout)
            .click({
              offset: {
                x: 83,
                y: 10,
              },
            });
    }

    await browser.close();

})().catch(err => {
    console.error(err);
    process.exit(1);
});
