const puppeteer = require('puppeteer'); // v23.0.0 or later

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    const timeout = 5000;
    page.setDefaultTimeout(timeout);

    {
        const targetPage = page;
        await targetPage.setViewport({
            width: 1561,
            height: 639
        })
    }
    {
        const targetPage = page;
        await targetPage.goto('https://integration-platform.listenai.com/ai-voice-firmwares/biz/prod');
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(返回首页) >>>> ::-p-aria([role=\\"generic\\"])'),
            targetPage.locator('button.ant-btn-primary > span'),
            targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[4]/button[1]/span)'),
            targetPage.locator(':scope >>> button.ant-btn-primary > span'),
            targetPage.locator('::-p-text(返回首页)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 45.5,
                y: 16,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(重新登录) >>>> ::-p-aria([role=\\"generic\\"])'),
            targetPage.locator('div.ant-modal-confirm-btns span'),
            targetPage.locator('::-p-xpath(/html/body/div[4]/div/div[2]/div/div[1]/div/div/div/div[2]/button/span)'),
            targetPage.locator(':scope >>> div.ant-modal-confirm-btns span')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 17.5,
                y: 8,
              },
            });
        await Promise.all(promises);
    }
    {
        const targetPage = page;
        const promises = [];
        const startWaitingForEvents = () => {
            promises.push(targetPage.waitForNavigation());
        }
        await puppeteer.Locator.race([
            targetPage.locator('::-p-aria(LSCloud 聆思开发者中心)'),
            targetPage.locator('div.login_main a'),
            targetPage.locator('::-p-xpath(//*[@id=\\"rc-tabs-0-panel-userSms\\"]/div/div/div/a)'),
            targetPage.locator(':scope >>> div.login_main a'),
            targetPage.locator('::-p-text(LSCloud 聆思开发者中心)')
        ])
            .setTimeout(timeout)
            .on('action', () => startWaitingForEvents())
            .click({
              offset: {
                x: 68.40625,
                y: 6.296875,
              },
            });
        await Promise.all(promises);
    }

    await browser.close();

})().catch(err => {
    console.error(err);
    process.exit(1);
});
