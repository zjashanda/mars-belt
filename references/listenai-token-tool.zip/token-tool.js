#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT_DIR = __dirname;

const DEFAULT_CONFIG = {
  profileDir: './profiles/listenai',
  tokenFile: './tokens/listenai-token.json',
  tokenTextFile: './tokens/listenai-token.txt',
  mainUrl: 'https://integration-platform.listenai.com/ai-voice-firmwares/biz/index',
  prodUrl: 'https://integration-platform.listenai.com/ai-voice-firmwares/biz/prod',
  userApiPath: '/ai-voice-firmwares/api/backend/auth/b/getLoginUser',
  headless: false,
  scanTimeoutMs: 10 * 60 * 1000,
  navigationTimeoutMs: 60000,
  afterClickDelayMs: 1800,
  launchArgs: [
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-features=TranslateUI',
  ],
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function resolvePath(value) {
  if (!value) return value;
  return path.isAbsolute(value) ? value : path.resolve(ROOT_DIR, value);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function ensureParent(filePath) {
  ensureDir(path.dirname(filePath));
}

function loadConfig(flags = {}) {
  const configPath = resolvePath(flags.config || './config.json');
  let userConfig = {};

  if (fs.existsSync(configPath)) {
    userConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }

  const config = {
    ...DEFAULT_CONFIG,
    ...userConfig,
  };

  for (const key of ['profileDir', 'tokenFile', 'tokenTextFile']) {
    if (flags[key]) config[key] = flags[key];
    config[key] = resolvePath(config[key]);
  }

  if (flags.timeoutMs) config.scanTimeoutMs = Number(flags.timeoutMs);
  if (flags.chrome) config.executablePath = flags.chrome;
  if (process.env.CHROME_PATH && !config.executablePath) {
    config.executablePath = process.env.CHROME_PATH;
  }

  return config;
}

function parseArgs(argv) {
  const args = [...argv];
  const command = args.shift() || 'help';
  const flags = {};

  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];

    if (!arg.startsWith('--')) {
      if (!flags._) flags._ = [];
      flags._.push(arg);
      continue;
    }

    const eqIndex = arg.indexOf('=');
    let key = arg.slice(2);
    let value = true;

    if (eqIndex !== -1) {
      key = arg.slice(2, eqIndex);
      value = arg.slice(eqIndex + 1);
    } else if (i + 1 < args.length && !args[i + 1].startsWith('--')) {
      value = args[i + 1];
      i += 1;
    }

    key = key.replace(/-([a-z])/g, (_, ch) => ch.toUpperCase());
    flags[key] = value;
  }

  return { command, flags };
}

function maskToken(token) {
  if (!token) return '';
  if (token.length <= 12) return `${token.slice(0, 2)}***${token.slice(-2)}`;
  return `${token.slice(0, 6)}...${token.slice(-6)}`;
}

function normalizeTokenValue(value) {
  let token = String(value || '').trim();
  if (!token) return '';

  // localStorage.TOKEN may be stored as a JSON string, e.g. "\"abc...\"".
  // Normalize it before validation/persistence; otherwise the backend returns
  // a malformed JSON error message containing embedded quotes.
  for (let i = 0; i < 2; i += 1) {
    if (!/^["[{]/.test(token)) break;
    try {
      const parsed = JSON.parse(token);
      if (typeof parsed === 'string') {
        token = parsed.trim();
        continue;
      }
      break;
    } catch (_) {
      break;
    }
  }

  token = token.replace(/^Bearer\s+/i, '').trim();
  return token;
}

function createTokenRecord(tokenInfo, validation, config) {
  return {
    token: tokenInfo.token,
    tokenMasked: maskToken(tokenInfo.token),
    source: tokenInfo.source,
    pageUrl: tokenInfo.pageUrl,
    validation,
    updatedAt: new Date().toISOString(),
    profileDir: config.profileDir,
    note: '请保护本文件和 profiles 目录，里面包含登录态或短期访问凭据。',
  };
}

function saveToken(record, config) {
  ensureParent(config.tokenFile);
  ensureParent(config.tokenTextFile);
  fs.writeFileSync(config.tokenFile, `${JSON.stringify(record, null, 2)}\n`, 'utf8');
  fs.writeFileSync(config.tokenTextFile, `${record.token}\n`, 'utf8');
}

function printTokenSaved(record, config) {
  console.log(`已保存 token：${record.tokenMasked}`);
  console.log(`JSON 文件：${config.tokenFile}`);
  console.log(`纯文本文件：${config.tokenTextFile}`);
}

async function loadPuppeteer() {
  try {
    return require('puppeteer');
  } catch (error) {
    throw new Error('未安装 puppeteer，请先运行：npm install');
  }
}

function computeHeadless(command, flags, config) {
  if (flags.headless) return true;
  if (flags.headful || flags.noHeadless) return false;
  if (command === 'init') return false;
  return Boolean(config.headless);
}

async function launchBrowser(command, flags, config) {
  const puppeteer = await loadPuppeteer();
  ensureDir(config.profileDir);

  const launchOptions = {
    headless: computeHeadless(command, flags, config),
    userDataDir: config.profileDir,
    defaultViewport: null,
    args: config.launchArgs,
  };

  if (config.executablePath) {
    launchOptions.executablePath = config.executablePath;
  }

  return puppeteer.launch(launchOptions);
}

async function newPreparedPage(browser, config) {
  const page = await browser.newPage();
  page.setDefaultTimeout(config.navigationTimeoutMs);
  page.setDefaultNavigationTimeout(config.navigationTimeoutMs);
  return page;
}

async function gotoSafe(page, url, config) {
  await page.goto(url, {
    waitUntil: 'domcontentloaded',
    timeout: config.navigationTimeoutMs,
  });
  await sleep(config.afterClickDelayMs);
}

async function readTokenInfo(page) {
  try {
    return await page.evaluate(() => {
      function normalizeTokenValue(value) {
        let token = String(value || '').trim();
        if (!token) return '';

        for (let i = 0; i < 2; i += 1) {
          if (!/^["[{]/.test(token)) break;
          try {
            const parsed = JSON.parse(token);
            if (typeof parsed === 'string') {
              token = parsed.trim();
              continue;
            }
            break;
          } catch (_) {
            break;
          }
        }

        return token.replace(/^Bearer\s+/i, '').trim();
      }

      function findToken(storage, storageName) {
        const exactKeys = [
          'TOKEN',
          'token',
          'accessToken',
          'access_token',
          'ACCESS_TOKEN',
          'Authorization',
          'authorization',
        ];

        for (const key of exactKeys) {
          const value = storage.getItem(key);
          const token = normalizeTokenValue(value);
          if (token && token.length > 6) {
            return { token, source: `${storageName}.${key}` };
          }
        }

        for (let i = 0; i < storage.length; i += 1) {
          const key = storage.key(i);
          const value = storage.getItem(key);
          if (!value || value.length <= 6) continue;

          if (/token/i.test(key)) {
            return { token: value.trim(), source: `${storageName}.${key}` };
          }

          if (/^\s*[{[]/.test(value)) {
            try {
              const parsed = JSON.parse(value);
              const stack = [parsed];
              while (stack.length) {
                const current = stack.shift();
                if (!current || typeof current !== 'object') continue;

                for (const [childKey, childValue] of Object.entries(current)) {
                  if (
                    /token/i.test(childKey)
                    && typeof childValue === 'string'
                    && normalizeTokenValue(childValue).length > 6
                  ) {
                    return {
                      token: normalizeTokenValue(childValue),
                      source: `${storageName}.${key}.${childKey}`,
                    };
                  }

                  if (childValue && typeof childValue === 'object') {
                    stack.push(childValue);
                  }
                }
              }
            } catch (_) {
              // Ignore non-JSON storage values.
            }
          }
        }

        return null;
      }

      const local = findToken(window.localStorage, 'localStorage');
      const session = findToken(window.sessionStorage, 'sessionStorage');
      const found = local || session || {};

      return {
        token: found.token || '',
        source: found.source || '',
        pageUrl: location.href,
      };
    });
  } catch (error) {
    return {
      token: '',
      source: '',
      pageUrl: page.url(),
      error: error.message,
    };
  }
}

async function validateToken(page, token, config) {
  if (!token) {
    return { ok: false, reason: 'missing token' };
  }

  try {
    return await page.evaluate(async ({ userApiPath, tokenValue }) => {
      const url = new URL(userApiPath, location.origin);
      url.searchParams.set('_', String(Date.now()));

      try {
        const response = await fetch(url.toString(), {
          method: 'GET',
          credentials: 'include',
          headers: {
            Authorization: tokenValue,
            token: tokenValue,
            'X-Token': tokenValue,
            'Cache-Control': 'no-cache',
          },
        });

        const text = await response.text();
        let body = null;
        try {
          body = JSON.parse(text);
        } catch (_) {
          body = null;
        }

        const code = body && body.code;
        const msg = body && body.msg ? String(body.msg) : '';
        const failedByBody = code === 401
          || code === 403
          || /token.*(失效|无效|过期|冻结|被冻结|expire|invalid|missing|frozen)/i.test(msg)
          || /token.*(失效|无效|过期|冻结|被冻结|expire|invalid|missing|frozen)/i.test(text);

        return {
          ok: response.ok && !failedByBody,
          httpStatus: response.status,
          code,
          msg,
        };
      } catch (error) {
        return {
          ok: null,
          reason: 'validation request failed',
          error: error.message,
        };
      }
    }, {
      userApiPath: config.userApiPath,
      tokenValue: token,
    });
  } catch (error) {
    return {
      ok: null,
      reason: 'validation page evaluation failed',
      error: error.message,
    };
  }
}

async function getValidatedToken(page, config, options = {}) {
  const tokenInfo = await readTokenInfo(page);
  if (!tokenInfo.token) {
    return { tokenInfo, validation: { ok: false, reason: 'not found in browser storage' } };
  }

  if (options.rejectToken && tokenInfo.token === options.rejectToken) {
    return { tokenInfo, validation: { ok: false, reason: 'same invalid token is still present' } };
  }

  const validation = await validateToken(page, tokenInfo.token, config);
  return { tokenInfo, validation };
}

async function isVisible(page, elementHandle) {
  return page.evaluate((element) => {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style
      && style.visibility !== 'hidden'
      && style.display !== 'none'
      && rect.width > 0
      && rect.height > 0;
  }, elementHandle);
}

async function clickAndSettle(page, elementHandle, config) {
  await Promise.all([
    page.waitForNavigation({
      waitUntil: 'domcontentloaded',
      timeout: config.navigationTimeoutMs,
    }).catch(() => null),
    elementHandle.click({ delay: 30 }).catch(async () => {
      await page.evaluate((element) => element.click(), elementHandle);
    }),
  ]);
  await sleep(config.afterClickDelayMs);
}

async function clickBySelector(page, selectors, config) {
  for (const selector of selectors) {
    const elements = await page.$$(selector);

    for (const element of elements) {
      if (await isVisible(page, element)) {
        await clickAndSettle(page, element, config);
        return true;
      }
    }
  }

  return false;
}

async function clickByText(page, texts, config) {
  const handle = await page.evaluateHandle((wantedTexts) => {
    function visible(element) {
      const style = window.getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style
        && style.visibility !== 'hidden'
        && style.display !== 'none'
        && rect.width > 0
        && rect.height > 0;
    }

    function actionable(element) {
      return element.closest('button,a,[role="button"],li.ant-dropdown-menu-item,.ant-btn')
        || element;
    }

    const candidates = Array.from(document.querySelectorAll(
      'button,a,span,div,li,[role="button"]',
    ));

    for (const text of wantedTexts) {
      const found = candidates.find((element) => {
        const content = (element.innerText || element.textContent || '').trim();
        return content.includes(text) && visible(element);
      });

      if (found) return actionable(found);
    }

    return null;
  }, texts);

  const element = handle.asElement();

  if (!element) {
    await handle.dispose();
    return false;
  }

  await clickAndSettle(page, element, config);
  await handle.dispose();
  return true;
}

async function clickFirst(page, action, config) {
  if (action.selectors && await clickBySelector(page, action.selectors, config)) {
    console.log(`已点击：${action.name}`);
    return true;
  }

  if (action.texts && await clickByText(page, action.texts, config)) {
    console.log(`已点击：${action.name}`);
    return true;
  }

  return false;
}

async function pageLooksLikeQrLogin(page) {
  try {
    return await page.evaluate(() => {
      const text = document.body ? document.body.innerText || '' : '';
      const hasQrText = /扫码|二维码|企业微信|微信/.test(text);
      const hasQrLikeNode = Boolean(document.querySelector('canvas, img[src*="qr"], iframe[src*="qr"]'));
      return hasQrText || hasQrLikeNode || location.href.includes('open.work.weixin.qq.com');
    });
  } catch (_) {
    return false;
  }
}

async function performLoginFlow(page, config, options = {}) {
  const timeoutMs = options.timeoutMs || config.scanTimeoutMs;
  const deadline = Date.now() + timeoutMs;
  const oldToken = options.rejectToken || '';
  let reportedQr = false;

  const actions = [
    {
      name: '返回首页',
      texts: ['返回首页'],
    },
    {
      name: '重新登录/确认',
      texts: ['重新登录', '确定', '确认'],
    },
    {
      name: 'LSCloud 登录入口',
      texts: ['LSCloud', '聆思开发者中心'],
      selectors: ['div.login_main a', 'a[href*="listenai.com/login"]'],
    },
    {
      name: '聆思员工登录',
      texts: ['聆思员工登录', '员工登录'],
      selectors: ['div.right-bottom > a.right-bottom-btn', 'a.right-bottom-btn'],
    },
  ];

  while (Date.now() < deadline) {
    const { tokenInfo, validation } = await getValidatedToken(page, config, {
      rejectToken: oldToken,
    });

    if (tokenInfo.token && (validation.ok === true || validation.ok === null)) {
      return { tokenInfo, validation };
    }

    for (const action of actions) {
      if (Date.now() >= deadline) break;

      const clicked = await clickFirst(page, action, config);
      if (!clicked) continue;

      const afterClick = await getValidatedToken(page, config, {
        rejectToken: oldToken,
      });

      if (
        afterClick.tokenInfo.token
        && (afterClick.validation.ok === true || afterClick.validation.ok === null)
      ) {
        return afterClick;
      }
    }

    if (!reportedQr && await pageLooksLikeQrLogin(page)) {
      console.log('检测到扫码登录页面：请在打开的浏览器中扫码完成登录。');
      reportedQr = true;
    }

    await sleep(2000);
  }

  return {
    tokenInfo: { token: '', source: '', pageUrl: page.url() },
    validation: { ok: false, reason: 'login timeout' },
  };
}

async function waitForTokenAfterManualLogin(page, config, options = {}) {
  const timeoutMs = options.timeoutMs || config.scanTimeoutMs;
  const deadline = Date.now() + timeoutMs;
  const oldToken = options.rejectToken || '';
  let reported = false;

  while (Date.now() < deadline) {
    const current = await getValidatedToken(page, config, { rejectToken: oldToken });
    if (
      current.tokenInfo.token
      && (current.validation.ok === true || current.validation.ok === null)
    ) {
      return current;
    }

    if (!reported && await pageLooksLikeQrLogin(page)) {
      console.log('等待扫码完成...');
      reported = true;
    }

    await sleep(2000);
  }

  return {
    tokenInfo: { token: '', source: '', pageUrl: page.url() },
    validation: { ok: false, reason: 'manual login timeout' },
  };
}

function requireToken(result) {
  return Boolean(result && result.tokenInfo && result.tokenInfo.token);
}

async function commandInit(flags, config) {
  console.log(`Profile 目录：${config.profileDir}`);
  console.log('首次初始化：浏览器会打开，请扫码或完成登录。');

  const browser = await launchBrowser('init', flags, config);
  let shouldClose = !flags.keepOpen;

  try {
    const page = await newPreparedPage(browser, config);
    await gotoSafe(page, config.mainUrl, config);

    let result = await getValidatedToken(page, config);

    if (!requireToken(result) || result.validation.ok === false) {
      result = await performLoginFlow(page, config, {
        timeoutMs: config.scanTimeoutMs,
        rejectToken: result.tokenInfo.token,
      });
    }

    if (!requireToken(result)) {
      result = await waitForTokenAfterManualLogin(page, config, {
        timeoutMs: config.scanTimeoutMs,
      });
    }

    if (!requireToken(result)) {
      throw new Error('初始化超时：没有在浏览器本地存储中找到 token。');
    }

    const record = createTokenRecord(result.tokenInfo, result.validation, config);
    saveToken(record, config);
    printTokenSaved(record, config);

    if (flags.keepOpen) {
      shouldClose = false;
      console.log('已按 --keep-open 保持浏览器打开。');
    }
  } finally {
    if (shouldClose) await browser.close();
  }
}

async function commandGet(flags, config) {
  const browser = await launchBrowser('get', flags, config);

  try {
    const page = await newPreparedPage(browser, config);
    await gotoSafe(page, config.mainUrl, config);

    let result = await getValidatedToken(page, config);
    const needsRefresh = !requireToken(result) || result.validation.ok === false;

    if (needsRefresh && !flags.noRefresh) {
      console.log('当前 token 不可用，尝试重新登录/刷新...');
      await gotoSafe(page, config.prodUrl, config);
      result = await performLoginFlow(page, config, {
        timeoutMs: config.scanTimeoutMs,
        rejectToken: result.tokenInfo.token,
      });
    }

    if (!requireToken(result)) {
      throw new Error('没有获取到 token；如果浏览器显示二维码，请运行 npm run init 重新扫码。');
    }

    const record = createTokenRecord(result.tokenInfo, result.validation, config);
    saveToken(record, config);

    if (flags.json) {
      console.log(JSON.stringify(record, null, 2));
    } else {
      printTokenSaved(record, config);
      if (record.validation.ok === false) {
        console.log(`注意：校验未通过：${record.validation.reason || record.validation.msg || 'unknown'}`);
      } else if (record.validation.ok === null) {
        console.log('注意：token 校验结果未知，但已从浏览器登录态中读取到 token。');
      }
    }
  } finally {
    await browser.close();
  }
}

async function commandRefresh(flags, config) {
  const browser = await launchBrowser('refresh', flags, config);

  try {
    const page = await newPreparedPage(browser, config);
    await gotoSafe(page, config.prodUrl, config);

    const current = await getValidatedToken(page, config);
    const result = await performLoginFlow(page, config, {
      timeoutMs: config.scanTimeoutMs,
      rejectToken: current.validation.ok === false ? current.tokenInfo.token : '',
    });

    if (!requireToken(result)) {
      throw new Error('刷新失败：没有获取到新的 token。需要打开浏览器重新扫码时请运行 npm run init。');
    }

    const record = createTokenRecord(result.tokenInfo, result.validation, config);
    saveToken(record, config);

    if (flags.json) {
      console.log(JSON.stringify(record, null, 2));
    } else {
      printTokenSaved(record, config);
    }
  } finally {
    await browser.close();
  }
}

async function commandStatus(flags, config) {
  const profileExists = fs.existsSync(config.profileDir);
  const tokenExists = fs.existsSync(config.tokenFile);
  let tokenRecord = null;

  if (tokenExists) {
    try {
      tokenRecord = JSON.parse(fs.readFileSync(config.tokenFile, 'utf8'));
    } catch (_) {
      tokenRecord = null;
    }
  }

  console.log(`Profile 目录：${config.profileDir}`);
  console.log(`Profile 是否存在：${profileExists ? '是' : '否'}`);
  console.log(`Token 文件：${config.tokenFile}`);
  console.log(`Token 文件是否存在：${tokenExists ? '是' : '否'}`);

  if (tokenRecord) {
    console.log(`Token：${tokenRecord.tokenMasked || maskToken(tokenRecord.token)}`);
    console.log(`更新时间：${tokenRecord.updatedAt || '未知'}`);
    console.log(`来源：${tokenRecord.source || '未知'}`);
  }

  if (!flags.check) return;

  console.log('正在打开浏览器检查当前登录态...');
  const browser = await launchBrowser('status', flags, config);

  try {
    const page = await newPreparedPage(browser, config);
    await gotoSafe(page, config.mainUrl, config);
    const result = await getValidatedToken(page, config);
    console.log(`浏览器内 token：${result.tokenInfo.token ? maskToken(result.tokenInfo.token) : '未找到'}`);
    console.log(`校验结果：${JSON.stringify(result.validation)}`);
  } finally {
    await browser.close();
  }
}

function printHelp() {
  console.log(`
ListenAI token 工具

用法：
  node token-tool.js init                 首次扫码初始化本机 profile
  node token-tool.js get                  读取/自动刷新 token 并写入 tokens 目录
  node token-tool.js refresh              强制走重新登录/刷新流程
  node token-tool.js status [--check]     查看本地 profile 和 token 状态

常用参数：
  --headless              无界面运行；需要扫码时不要使用
  --headful               强制有界面运行
  --timeout-ms 600000     扫码/登录等待时间
  --profile-dir <path>    指定 profile 目录
  --token-file <path>     指定 token JSON 输出路径
  --chrome <path>         指定 Chrome/Chromium 可执行文件
  --json                  get/refresh 时向 stdout 输出完整 JSON
  --no-refresh            get 时只读取，不自动刷新
`);
}

async function main(argv = process.argv.slice(2)) {
  const { command, flags } = parseArgs(argv);
  const config = loadConfig(flags);

  switch (command) {
    case 'init':
      await commandInit(flags, config);
      break;
    case 'get':
      await commandGet(flags, config);
      break;
    case 'refresh':
      await commandRefresh(flags, config);
      break;
    case 'status':
      await commandStatus(flags, config);
      break;
    case 'help':
    case '--help':
    case '-h':
      printHelp();
      break;
    default:
      printHelp();
      throw new Error(`未知命令：${command}`);
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error.message || error);
    process.exit(1);
  });
}

module.exports = { main };
