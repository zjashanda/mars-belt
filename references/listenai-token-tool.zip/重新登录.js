﻿'use strict';

// 兼容旧入口：使用已保存的本机 profile 重新登录/刷新 token。
const { main } = require('./token-tool');

main(['refresh', ...process.argv.slice(2)]).catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
