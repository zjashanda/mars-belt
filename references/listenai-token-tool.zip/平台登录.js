﻿'use strict';

// 兼容旧入口：首次扫码初始化本机 profile，后续请优先使用 npm run init。
const { main } = require('./token-tool');

main(['init', ...process.argv.slice(2)]).catch((error) => {
  console.error(error.message || error);
  process.exit(1);
});
