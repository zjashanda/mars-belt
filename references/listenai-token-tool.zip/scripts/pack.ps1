$ErrorActionPreference = 'Stop'

$root = Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')
$dist = Join-Path $root 'dist'
$stage = Join-Path $dist 'listenai-token-tool'
$zip = Join-Path $dist 'listenai-token-tool.zip'

New-Item -ItemType Directory -Force -Path $dist | Out-Null

$resolvedDist = (Resolve-Path -LiteralPath $dist).Path
$stageFull = [System.IO.Path]::GetFullPath($stage)
if (-not $stageFull.StartsWith($resolvedDist, [System.StringComparison]::OrdinalIgnoreCase)) {
  throw "Refuse to clean staging path outside dist: $stageFull"
}

if (Test-Path -LiteralPath $stage) {
  Remove-Item -LiteralPath $stage -Recurse -Force
}
if (Test-Path -LiteralPath $zip) {
  Remove-Item -LiteralPath $zip -Force
}

New-Item -ItemType Directory -Force -Path $stage | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'profiles') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'tokens') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'scripts') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'legacy') | Out-Null

$rootPath = $root.Path
$files = @()
$files += Get-ChildItem -LiteralPath $rootPath -Force -File | Where-Object {
  $_.Name -in @('token-tool.js', 'package.json', 'config.example.json', '.gitignore') `
    -or ($_.Extension -eq '.md' -and $_.Name -ne 'plan.md') `
    -or ($_.Extension -eq '.js')
}
$files += Get-ChildItem -LiteralPath (Join-Path $rootPath 'profiles') -Force -File
$files += Get-ChildItem -LiteralPath (Join-Path $rootPath 'tokens') -Force -File
$files += Get-ChildItem -LiteralPath (Join-Path $rootPath 'scripts') -Force -File
$files += Get-ChildItem -LiteralPath (Join-Path $rootPath 'legacy') -Force -File

$files = $files | Sort-Object FullName -Unique

foreach ($sourceItem in $files) {
  $relativePath = $sourceItem.FullName.Substring($rootPath.Length).TrimStart('\', '/')
  $target = Join-Path $stage $relativePath
  $targetDir = Split-Path -Parent $target
  New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
  Copy-Item -LiteralPath $sourceItem.FullName -Destination $target -Force
}

Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -Force
Remove-Item -LiteralPath $stage -Recurse -Force
Write-Host "Created: $zip"
