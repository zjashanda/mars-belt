#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const root = path.resolve(__dirname, '..');
const dist = path.join(root, 'dist');
const zipPath = path.join(dist, 'listenai-token-tool.zip');

const crcTable = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i += 1) {
    let value = i;
    for (let j = 0; j < 8; j += 1) {
      value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    }
    table[i] = value >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let value = 0xffffffff;
  for (const byte of buffer) {
    value = crcTable[(value ^ byte) & 0xff] ^ (value >>> 8);
  }
  return (value ^ 0xffffffff) >>> 0;
}

function dosDateTime(date) {
  const year = Math.max(date.getFullYear(), 1980);
  const dosTime = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { dosTime, dosDate };
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  const result = [];

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      result.push(...walk(fullPath));
    } else if (entry.isFile()) {
      result.push(fullPath);
    }
  }

  return result;
}

function listFiles() {
  const files = [];

  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    if (!entry.isFile()) continue;

    const fullPath = path.join(root, entry.name);
    const ext = path.extname(entry.name).toLowerCase();
    if (
      ['token-tool.js', 'package.json', 'config.example.json', '.gitignore'].includes(entry.name)
      || (ext === '.js')
      || (ext === '.md' && entry.name !== 'plan.md')
    ) {
      files.push(fullPath);
    }
  }

  for (const folder of ['profiles', 'tokens', 'scripts', 'legacy']) {
    files.push(...walk(path.join(root, folder)));
  }

  return [...new Set(files)]
    .filter((file) => !file.includes(`${path.sep}dist${path.sep}`))
    .sort((a, b) => a.localeCompare(b));
}

function writeUInt16(value) {
  const buffer = Buffer.alloc(2);
  buffer.writeUInt16LE(value);
  return buffer;
}

function writeUInt32(value) {
  const buffer = Buffer.alloc(4);
  buffer.writeUInt32LE(value >>> 0);
  return buffer;
}

function createZip(files, output) {
  const chunks = [];
  const central = [];
  let offset = 0;

  for (const file of files) {
    const stat = fs.statSync(file);
    const raw = fs.readFileSync(file);
    const compressed = zlib.deflateRawSync(raw, { level: 9 });
    const name = path.relative(root, file).split(path.sep).join('/');
    const nameBuffer = Buffer.from(name, 'utf8');
    const checksum = crc32(raw);
    const { dosTime, dosDate } = dosDateTime(stat.mtime);

    const localHeader = Buffer.concat([
      writeUInt32(0x04034b50),
      writeUInt16(20),
      writeUInt16(0x0800),
      writeUInt16(8),
      writeUInt16(dosTime),
      writeUInt16(dosDate),
      writeUInt32(checksum),
      writeUInt32(compressed.length),
      writeUInt32(raw.length),
      writeUInt16(nameBuffer.length),
      writeUInt16(0),
      nameBuffer,
    ]);

    chunks.push(localHeader, compressed);

    central.push(Buffer.concat([
      writeUInt32(0x02014b50),
      writeUInt16(20),
      writeUInt16(20),
      writeUInt16(0x0800),
      writeUInt16(8),
      writeUInt16(dosTime),
      writeUInt16(dosDate),
      writeUInt32(checksum),
      writeUInt32(compressed.length),
      writeUInt32(raw.length),
      writeUInt16(nameBuffer.length),
      writeUInt16(0),
      writeUInt16(0),
      writeUInt16(0),
      writeUInt16(0),
      writeUInt32(0),
      writeUInt32(offset),
      nameBuffer,
    ]));

    offset += localHeader.length + compressed.length;
  }

  const centralStart = offset;
  const centralBuffer = Buffer.concat(central);
  const end = Buffer.concat([
    writeUInt32(0x06054b50),
    writeUInt16(0),
    writeUInt16(0),
    writeUInt16(files.length),
    writeUInt16(files.length),
    writeUInt32(centralBuffer.length),
    writeUInt32(centralStart),
    writeUInt16(0),
  ]);

  ensureDir(path.dirname(output));
  fs.writeFileSync(output, Buffer.concat([...chunks, centralBuffer, end]));
}

const files = listFiles();
createZip(files, zipPath);
console.log(`Created: ${zipPath}`);
console.log(`Files: ${files.length}`);
